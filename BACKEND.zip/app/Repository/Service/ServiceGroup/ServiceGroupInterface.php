<?php

namespace App\Repository\Service\ServiceGroup;

interface ServiceGroupInterface
{
    public function serviceGroupList(array $idListAllow);
}
