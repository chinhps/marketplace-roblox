<?php

namespace App\Repository\RechargeList;

interface RechargeListInterface
{
    public function getByKey(string $key);
}
