<?php

namespace App\Repository\Event;

interface EventInterface
{
    public function getLastEvent();
}
